#!/bin/bash

while true; do
	date >> /home/ubuntu/date.log
	sleep 3
done
